﻿namespace Class.Pages.class_diagram_and_scaffolding
{
    public class AccountHolder
    {
    public int AccountHolderID { get; set; }
    
    public string First_name { get; set; }


    public string Last_name { get; set; }

     public DateTime Date_Of_Birth { get; set; }

        public List<BankAccount>? BankAccountID { get; set; }

    }
}
