using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RecruitCatnandisv_updated10_.Pages
{
    public class ourteamModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
