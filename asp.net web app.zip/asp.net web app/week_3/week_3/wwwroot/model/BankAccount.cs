﻿namespace week_3.wwwroot.model
{
    public class BankAccount
    {
       
    }
}
